package com.tmage.decorblock

import net.minecraft.data.DataGenerator
import net.minecraft.resources.ResourceLocation
import net.minecraft.world.level.block.Block
import net.minecraftforge.client.model.generators.BlockStateProvider
import net.minecraftforge.common.data.ExistingFileHelper
import net.minecraftforge.data.event.GatherDataEvent
import net.minecraftforge.registries.RegistryObject
import java.util.function.Supplier

object ModDataGenerators {

    fun gatherData(event: GatherDataEvent) {
        val generator = event.generator

        generator.addProvider(
            event.includeClient(),
            ModBlockStateProvider(generator, DecorBlockMod.MOD_ID, event.existingFileHelper)
        )
    }

    class ModBlockStateProvider(gen: DataGenerator, modId: String, exFileHelper: ExistingFileHelper) :
        BlockStateProvider(gen.packOutput, modId, exFileHelper) {

        override fun registerStatesAndModels() {
            // Генерируем модели напрямую из списков блоков ModBlocks

            // 1. Wood Planks
            ModBlocks.PLANKS.forEach { generateSimpleCube(it, "wood_planks") }

            // 2. Fabric (Шерсть и ковры)
            ModBlocks.WOOLS.forEach { generateSimpleCube(it, "fabric") }
            ModBlocks.CARPETS.forEach { generateSimpleCube(it, "fabric") }

            // 3. Metal Panels
            ModBlocks.METAL_PANELS.forEach { generateSimpleCube(it, "metal") }

            // 4. Concrete
            ModBlocks.CONCRETE_BLOCKS.forEach { generateSimpleCube(it, "concrete") }

            // 5. Stone & Roof
            ModBlocks.COBBLE.forEach { generateSimpleCube(it, "stone") }
            ModBlocks.BRICKS.forEach { generateSimpleCube(it, "stone") }
            ModBlocks.POLISHED.forEach { generateSimpleCube(it, "stone_polished") }
            ModBlocks.ROOF_SHINGLES.forEach { generateSimpleCube(it, "roof") }

            // 6. Tiles & Mosaic
            ModBlocks.TILES.forEach { generateSimpleCube(it, "tiles") }
            ModBlocks.MOSAIC.forEach { generateSimpleCube(it, "tiles") }

            // 7. Ornaments & Glass
            ModBlocks.ORNAMENT_CROSS.forEach { generateSimpleCube(it, "ornament") }
            ModBlocks.ORNAMENT_DIAMOND.forEach { generateSimpleCube(it, "ornament") }
            ModBlocks.GLASS_BLOCKS.forEach { generateSimpleCube(it, "glass") }
        }

        // Безопасный хелпер-метод без ручного поиска по строкам
        private fun generateSimpleCube(registryObject: Supplier<out Block>, folder: String) {
            val entry = registryObject as RegistryObject<out Block>
            val block = entry.get()
            val name = entry.id.path

            // Путь к текстуре внутри вашей папки ресурсов
            val textureLoc = ResourceLocation(DecorBlockMod.MOD_ID, "block/$folder/$name")

            // Создаем модель блока и стейт
            val blockModel = models().cubeAll(name, textureLoc)
            simpleBlock(block, blockModel)

            // Создаем модель предмета
            simpleBlockItem(block, blockModel)
        }
    }
}