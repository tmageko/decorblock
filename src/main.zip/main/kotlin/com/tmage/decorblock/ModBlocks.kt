package com.tmage.decorblock

import net.minecraft.world.item.BlockItem
import net.minecraft.world.item.Item
import net.minecraft.world.level.block.Block
import net.minecraft.world.level.block.SoundType
import net.minecraft.world.level.block.state.BlockBehaviour
import net.minecraftforge.eventbus.api.IEventBus
import net.minecraftforge.registries.DeferredRegister
import net.minecraftforge.registries.ForgeRegistries
import java.util.function.Supplier

object ModBlocks {
    val REGISTRY: DeferredRegister<Block> = DeferredRegister.create(ForgeRegistries.BLOCKS, DecorBlockMod.MOD_ID)
    val ITEM_REGISTRY: DeferredRegister<Item> = DeferredRegister.create(ForgeRegistries.ITEMS, DecorBlockMod.MOD_ID)

    // --- НАСТРОЙКИ СВОЙСТВ ДЛЯ МАТЕРИАЛОВ (Универсальные для всех версий) ---
    private val WOOD_PROP = BlockBehaviour.Properties.of().strength(2.0f, 3.0f).sound(SoundType.WOOD)
    private val WOOL_PROP = BlockBehaviour.Properties.of().strength(0.8f).sound(SoundType.WOOL)
    private val CARPET_PROP = BlockBehaviour.Properties.of().strength(0.1f).sound(SoundType.WOOL)
    private val METAL_PROP = BlockBehaviour.Properties.of().strength(5.0f, 6.0f).sound(SoundType.METAL).requiresCorrectToolForDrops()
    private val STONE_PROP = BlockBehaviour.Properties.of().strength(1.5f, 6.0f).sound(SoundType.STONE).requiresCorrectToolForDrops()
    private val GLASS_PROP = BlockBehaviour.Properties.of().strength(0.3f).sound(SoundType.GLASS).noOcclusion()

    // --- 1. WOOD PLANKS (Доски: варианты 1 и 2)
    val WOOD_TYPES = listOf("oak", "birch", "spruce", "dark_oak", "acacia", "cherry", "pale_pine", "mahogany", "ash", "walnut")
    val PLANKS = WOOD_TYPES.flatMap { type ->
        listOf(
            registerBlock("planks_${type}_1") { Block(WOOD_PROP) },
            registerBlock("planks_${type}_2") { Block(WOOD_PROP) }
        )
    }

    // --- 2. FABRIC (Шерсть и ковры)
    val WOOL_COLORS = listOf("crimson", "azure", "teal", "charcoal", "emerald", "mint", "ivory", "sand", "plum", "amber", "lavender", "coral")
    val CARPET_COMBOS = listOf(
        "plum_azure", "emerald_charcoal", "sand_emerald", "crimson_amber",
        "charcoal_coral", "ivory_mint", "coral_sand", "amber_ivory",
        "teal_plum", "lavender_teal", "azure_lavender", "mint_crimson"
    )
    val WOOLS = WOOL_COLORS.map { color ->
        registerBlock("wool_$color") { Block(WOOL_PROP) }
    }
    val CARPETS = CARPET_COMBOS.map { combo ->
        registerBlock("carpet_$combo") { Block(CARPET_PROP) }
    }

    // --- 3. METAL PANELS (Варианты 1 и 2)
    val METAL_TYPES = listOf("iron", "copper", "gold", "dark_steel", "bronze", "silver", "gunmetal", "rust")
    val METAL_PANELS = METAL_TYPES.flatMap { type ->
        listOf(
            registerBlock("panel_${type}_1") { Block(METAL_PROP) },
            registerBlock("panel_${type}_2") { Block(METAL_PROP) }
        )
    }

    // --- 4. CONCRETE (Бетон: варианты 1 и 2)
    val CONCRETE_TYPES = listOf("light_grey", "dark", "blue_grey", "warm_grey", "sand_beige", "blush")
    val CONCRETE_BLOCKS = CONCRETE_TYPES.flatMap { type ->
        listOf(
            registerBlock("concrete_${type}_1") { Block(STONE_PROP) },
            registerBlock("concrete_${type}_2") { Block(STONE_PROP) }
        )
    }

    // --- 5. STONE & SHINGLES (Камень, Кирпичи, Плитка, Крыша)
    val STONE_MATERIALS = listOf("limestone", "slate", "sandstone", "obsidian", "clay_brick", "terracotta", "granite", "basalt", "marble_white", "marble_black")
    val COBBLE = STONE_MATERIALS.map { registerBlock("cobble_$it") { Block(STONE_PROP) } }
    val BRICKS = STONE_MATERIALS.map { registerBlock("bricks_$it") { Block(STONE_PROP) } }
    val POLISHED = STONE_MATERIALS.map { registerBlock("polished_$it") { Block(STONE_PROP) } }

    val ROOF_SHINGLES = WOOD_TYPES.map { type ->
        registerBlock("shingles_$type") { Block(WOOD_PROP) }
    }

    // --- 6. TILES & MOSAIC (Плитка и мозаика)
    val TILE_COLORS = listOf("bw", "rose", "slate", "green", "blue", "gold")
    val TILE_SIZES = listOf("2px", "4px", "8px")
    val TILES = TILE_COLORS.flatMap { color ->
        TILE_SIZES.map { size ->
            registerBlock("tiles_checker_${color}_$size") { Block(STONE_PROP) }
        }
    }
    val MOSAIC = TILE_COLORS.map { color ->
        registerBlock("mosaic_checker_$color") { Block(STONE_PROP) }
    }

    // --- 7. ORNAMENTS & GLASS (Орнаменты и цветные стекла)
    val ORNAMENT_CROSS = (1..6).map { registerBlock("ornament_cross_$it") { Block(STONE_PROP) } }
    val ORNAMENT_DIAMOND = (1..6).map { registerBlock("ornament_diamond_$it") { Block(STONE_PROP) } }

    val GLASS_COLORS = listOf("clear", "red", "amber_glass", "blue", "purple", "green")
    val GLASS_BLOCKS = GLASS_COLORS.map { color ->
        registerBlock("glass_$color") { Block(GLASS_PROP) }
    }

    // Хелпер-метод для автоматической одновременной регистрации Блока + Предмета блока
    private fun <T : Block> registerBlock(name: String, blockSupplier: Supplier<T>): Supplier<T> {
        val block = REGISTRY.register(name, blockSupplier)
        ITEM_REGISTRY.register(name) { BlockItem(block.get(), Item.Properties()) }
        return block
    }

    // Метод совместим со стандартным Forge IEventBus и KEventBus от KotlinForForge
    fun register(eventBus: IEventBus) {
        REGISTRY.register(eventBus)
        ITEM_REGISTRY.register(eventBus)
    }
}